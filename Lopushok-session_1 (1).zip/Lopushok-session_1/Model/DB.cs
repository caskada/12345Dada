﻿namespace Lopushok.Model
{
    /// <summary>
    /// Класс базы данных
    /// </summary>
    public class DB
    {
        /// <summary>
        /// Объект базы данных
        /// </summary>
        public static LopushokEntities entities = new LopushokEntities();
    }
}
